This is an alpha version of the 8-Track project.
8-Track is a modular automated filament changer that is scaleable and compatible with any KLIPPER 3d printer.
Specifically 8-Track Raven's purpose is to do public testing of critical components at a lower price point.
Raven retains the same cassettes as the 8-Track while simplifying the hub and uses an off the shelf MCU.

The goal of alpha testing this project is to refine the cassettes as much as possible and prove reliability of the system.
Features like active filament drying are being worked on but do not currently have a timeline.


Almost everything is subject to change unless specified as set in stone such as:
Cassette dimensions, 8-Track Raven frame.

*Insert lots more reading material here *later**