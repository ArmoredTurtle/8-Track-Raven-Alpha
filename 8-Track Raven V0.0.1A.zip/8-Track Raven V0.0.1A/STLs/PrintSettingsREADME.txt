All parts should be printed in these settings unless specifically called out here as otherwise.

.4mm nozzle
.2 layer height
4 perimeters 
4 bottom layers
4 top layers (0.8mm)
15% GYROID infill

Material choice:
PLA, PETG and ABS have been tested, all work however PETG is not recommended for extruder parts or drop plates.
When using heated inserts, be sure to use appropriate temperatures for your selected material.

Part call out!
	Guidler: same settings with 6 perimeters and 40% infill
	Servo_Arm: Same as guidler unless pla. If in PLA print at 100% infill.
	6-1Hub: Increase infill to 20% to ensure proper support of filament paths.